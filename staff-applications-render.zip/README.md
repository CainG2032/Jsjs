# Staff Applications Website

Render-ready Moderator + Content Creator application site.

## Features

- Home page with Moderator and Content Creator choices.
- Shows OPEN/CLOSED status.
- Moderator questions:
  - How old are you?
  - Discord username
  - Moderation/community experience
  - How active are you?
  - Why do you want to be a moderator?
- Content Creator questions:
  - Why do you want to be a Content Creator?
  - What tier are you applying for?
  - How old are you?
  - YouTube channel link
  - Discord username
  - Anything else you'd like us to know?
- Owner-only panel.
- Open/close each application independently.
- Review All / Moderator / CC applications.
- Mark applications pending, reviewed, accepted, or rejected.
- Delete applications.
- PostgreSQL persistence for Render.
- Server-side authentication and validation.

## Deploy with Render

### Easiest method

1. Create a GitHub repository.
2. Upload every file/folder from this project.
3. In Render, choose **New → Blueprint** and select the GitHub repository.
4. Render will read `render.yaml` and create the web service + PostgreSQL database.
5. Set these environment variables on the web service:
   - `ADMIN_USERNAME` = your private owner username
   - `ADMIN_PASSWORD` = a strong private password
6. Deploy.
7. Open your Render URL.

The owner panel is at:

`https://YOUR-RENDER-DOMAIN/admin.html`

Do not put the admin password inside the GitHub files.

## Important

The database is required because normal Render web-service files should not be treated as permanent application storage.

The `render.yaml` creates a PostgreSQL database and connects it with `DATABASE_URL`.
