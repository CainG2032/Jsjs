const express = require("express");
const session = require("express-session");
const pg = require("pg");
const path = require("path");
const crypto = require("crypto");

const app = express();
const PORT = process.env.PORT || 10000;
const ADMIN_USERNAME = process.env.ADMIN_USERNAME || "owner";
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;

if (!ADMIN_PASSWORD) {
  console.warn("WARNING: ADMIN_PASSWORD is not set. Set it in Render Environment Variables.");
}

const pool = new pg.Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_URL ? { rejectUnauthorized: false } : false
});

app.set("trust proxy", 1);
app.use(express.json({ limit: "50kb" }));
app.use(express.urlencoded({ extended: false, limit: "50kb" }));

app.use(session({
  secret: process.env.SESSION_SECRET || crypto.randomBytes(32).toString("hex"),
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    maxAge: 1000 * 60 * 60 * 8
  }
}));

app.use(express.static(path.join(__dirname, "public")));

async function initDb() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS application_settings (
      id INTEGER PRIMARY KEY,
      mod_open BOOLEAN NOT NULL DEFAULT TRUE,
      cc_open BOOLEAN NOT NULL DEFAULT TRUE
    );

    INSERT INTO application_settings (id, mod_open, cc_open)
    VALUES (1, TRUE, TRUE)
    ON CONFLICT (id) DO NOTHING;

    CREATE TABLE IF NOT EXISTS applications (
      id BIGSERIAL PRIMARY KEY,
      type VARCHAR(10) NOT NULL CHECK (type IN ('mod', 'cc')),
      age VARCHAR(30) NOT NULL,
      discord VARCHAR(100) NOT NULL,
      experience TEXT,
      activity TEXT,
      why TEXT NOT NULL,
      tier VARCHAR(100),
      youtube TEXT,
      other TEXT,
      status VARCHAR(20) NOT NULL DEFAULT 'pending',
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
  `);
}

function requireAdmin(req, res, next) {
  if (req.session && req.session.isAdmin) return next();
  return res.status(401).json({ error: "Unauthorized" });
}

function clean(value, max) {
  if (typeof value !== "string") return "";
  return value.trim().slice(0, max);
}

app.get("/api/status", async (req, res) => {
  try {
    const result = await pool.query(
      "SELECT mod_open, cc_open FROM application_settings WHERE id = 1"
    );
    res.json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Could not load application status." });
  }
});

app.post("/api/applications", async (req, res) => {
  try {
    const type = req.body.type === "cc" ? "cc" : "mod";
    const settings = await pool.query(
      "SELECT mod_open, cc_open FROM application_settings WHERE id = 1"
    );

    const isOpen = type === "mod" ? settings.rows[0].mod_open : settings.rows[0].cc_open;
    if (!isOpen) return res.status(403).json({ error: "This application is currently closed." });

    const age = clean(req.body.age, 30);
    const discord = clean(req.body.discord, 100);
    const why = clean(req.body.why, 3000);

    if (!age || !discord || !why) {
      return res.status(400).json({ error: "Please fill out all required fields." });
    }

    if (type === "mod") {
      const experience = clean(req.body.experience, 3000);
      const activity = clean(req.body.activity, 1000);

      if (!experience || !activity) {
        return res.status(400).json({ error: "Please fill out all required fields." });
      }

      await pool.query(
        `INSERT INTO applications
         (type, age, discord, experience, activity, why)
         VALUES ($1, $2, $3, $4, $5, $6)`,
        [type, age, discord, experience, activity, why]
      );
    } else {
      const tier = clean(req.body.tier, 100);
      const youtube = clean(req.body.youtube, 500);
      const other = clean(req.body.other, 3000);

      if (!tier || !youtube || !other) {
        return res.status(400).json({ error: "Please fill out all required fields." });
      }

      await pool.query(
        `INSERT INTO applications
         (type, age, discord, why, tier, youtube, other)
         VALUES ($1, $2, $3, $4, $5, $6, $7)`,
        [type, age, discord, why, tier, youtube, other]
      );
    }

    res.json({ ok: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Could not submit application." });
  }
});

app.post("/api/admin/login", (req, res) => {
  const username = clean(req.body.username, 100);
  const password = typeof req.body.password === "string" ? req.body.password : "";

  if (!ADMIN_PASSWORD || username !== ADMIN_USERNAME || password !== ADMIN_PASSWORD) {
    return res.status(401).json({ error: "Invalid login." });
  }

  req.session.isAdmin = true;
  res.json({ ok: true });
});

app.post("/api/admin/logout", (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

app.get("/api/admin/me", (req, res) => {
  res.json({ loggedIn: !!(req.session && req.session.isAdmin) });
});

app.get("/api/admin/settings", requireAdmin, async (req, res) => {
  const result = await pool.query(
    "SELECT mod_open, cc_open FROM application_settings WHERE id = 1"
  );
  res.json(result.rows[0]);
});

app.post("/api/admin/settings", requireAdmin, async (req, res) => {
  const modOpen = !!req.body.modOpen;
  const ccOpen = !!req.body.ccOpen;

  await pool.query(
    "UPDATE application_settings SET mod_open = $1, cc_open = $2 WHERE id = 1",
    [modOpen, ccOpen]
  );

  res.json({ ok: true, modOpen, ccOpen });
});

app.get("/api/admin/applications", requireAdmin, async (req, res) => {
  const type = req.query.type === "cc" ? "cc" : req.query.type === "mod" ? "mod" : null;

  const result = type
    ? await pool.query(
        "SELECT * FROM applications WHERE type = $1 ORDER BY created_at DESC",
        [type]
      )
    : await pool.query("SELECT * FROM applications ORDER BY created_at DESC");

  res.json(result.rows);
});

app.patch("/api/admin/applications/:id", requireAdmin, async (req, res) => {
  const id = Number(req.params.id);
  const status = ["pending", "reviewed", "accepted", "rejected"].includes(req.body.status)
    ? req.body.status
    : null;

  if (!Number.isInteger(id) || !status) {
    return res.status(400).json({ error: "Invalid request." });
  }

  await pool.query(
    "UPDATE applications SET status = $1 WHERE id = $2",
    [status, id]
  );

  res.json({ ok: true });
});

app.delete("/api/admin/applications/:id", requireAdmin, async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) return res.status(400).json({ error: "Invalid ID." });

  await pool.query("DELETE FROM applications WHERE id = $1", [id]);
  res.json({ ok: true });
});

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

initDb()
  .then(() => {
    app.listen(PORT, () => console.log(`Applications site running on port ${PORT}`));
  })
  .catch((err) => {
    console.error("Database initialization failed:", err);
    process.exit(1);
  });
